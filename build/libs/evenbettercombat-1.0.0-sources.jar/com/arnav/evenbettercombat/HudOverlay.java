package com.arnav.evenbettercombat;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;

@Environment(EnvType.CLIENT)
public final class HudOverlay {
    private static final int MARGIN = 8;
    private static final int PAD_X = 5;
    private static final int PAD_Y = 3;
    private static final int LINE_H = 10;
    private static final int BG = 0x99000000;
    private static final int WHITE = 0xFFFFFF;
    private static final int DIM = 0x888888;

    public static void render(class_332 ctx, class_9779 tickCounter) {
        if (!TrackerState.hudVisible) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842) return;

        class_327 tr = client.field_1772;
        String deathLine = "☠ Deaths: " + TrackerState.deaths;
        String streakLine = TrackerState.streak > 0
            ? "⚔ Streak: " + TrackerState.streak + "  (best: " + TrackerState.bestStreak + ")"
            : null;

        int lineCount = streakLine != null ? 2 : 1;
        int width = tr.method_1727(deathLine);
        if (streakLine != null) width = Math.max(width, tr.method_1727(streakLine));

        int boxW = width + PAD_X * 2;
        int boxH = lineCount * LINE_H + PAD_Y * 2 - 1;

        ctx.method_25294(MARGIN, MARGIN, MARGIN + boxW, MARGIN + boxH, BG);

        int textX = MARGIN + PAD_X;
        int textY = MARGIN + PAD_Y;
        ctx.method_25303(tr, deathLine, textX, textY, TrackerState.streak == 0 ? DIM : WHITE);
        if (streakLine != null) {
            ctx.method_25303(tr, streakLine, textX, textY + LINE_H, WHITE);
        }
    }
}
