package com.arnav.evenbettercombat;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public final class EvenBetterCombatClient implements ClientModInitializer {
    private static class_304 toggleHud;
    private static boolean wasDead = false;
    private static String currentServer = "singleplayer";

    private static final int[] MILESTONES = {5, 10, 15, 20, 25, 30, 50};

    @Override
    public void onInitializeClient() {
        toggleHud = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.evenbettercombat.toggle_hud",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_H,
            "key.category.evenbettercombat.general"
        ));

        HudRenderCallback.EVENT.register(HudOverlay::render);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleHud.method_1436()) {
                TrackerState.hudVisible = !TrackerState.hudVisible;
            }
            if (client.field_1724 == null) return;
            boolean isDead = client.field_1724.method_6032() <= 0;
            if (isDead && !wasDead) {
                TrackerState.onDeath();
                StatsStorage.save(currentServer);
            }
            wasDead = isDead;
        });

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null) return;
            String localName = client.field_1724.method_5477().getString();
            String msg = message.getString();
            if (msg.startsWith(localName + " ")) return; // local player died — handled by tick
            if (msg.contains(localName)) {
                TrackerState.onKill();
                StatsStorage.save(currentServer);
                checkMilestone(client, TrackerState.streak);
            }
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            wasDead = false;
            currentServer = handler.method_48296().method_10755() != null
                ? handler.method_48296().method_10755().toString()
                : "singleplayer";
            TrackerState.reset();
            StatsStorage.load(currentServer);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            StatsStorage.save(currentServer);
        });
    }

    private static void checkMilestone(class_310 client, int streak) {
        for (int m : MILESTONES) {
            if (streak == m) {
                client.field_1705.method_1743().method_1812(
                    class_2561.method_43470("§6[Even Better Combat] §e" + streak + " kill streak! Keep it up!")
                );
                break;
            }
        }
    }
}
